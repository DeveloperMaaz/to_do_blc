import 'package:flutter/material.dart';
import 'package:to_do_blc/features/presentation/models/task_model.dart';

class AddedLists extends StatefulWidget {

   late final List<TaskModel> addedTasks;

   AddedLists(this.addedTasks);
  @override
  _AddedListsState createState() => _AddedListsState();
}

class _AddedListsState extends State<AddedLists> {
  @override
  Widget build(BuildContext context) {
    return  Container(
        height: 200,
        child:  widget.addedTasks.isEmpty?Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
        Text("No Transaction Yet.!",style: TextStyle(
        fontSize: 26.0,
        color: Colors.black54,
        fontWeight: FontWeight.bold,
    ),),
    ],
    ):ListView.builder(
    itemCount: widget.addedTasks.length,
    itemBuilder:(ctx,index){

      return Card(
        elevation: 5,
        child: ListTile(
      title: Text('${widget.addedTasks[index].title}'),
    subtitle: Text('${widget.addedTasks[index].description}'),
      ),);
    }
    )
    );
  }
}
