import 'package:flutter/material.dart';
import 'package:to_do_blc/features/presentation/models/task_model.dart';
import 'package:to_do_blc/features/presentation/widget/create_task.dart';

import '../../../added_tasks.dart';

class MainScreen extends StatefulWidget {
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  List<TaskModel> tasks = [


  ];

  void _userTasks(
    String id,
    String title,
    String description,
  ) {
    final addTask = TaskModel(
      id: DateTime.now().toString(),
      title: title,
      description: description,
    );

    setState(() {
      tasks.add(addTask);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (ctx) => CreateTask(_userTasks)));
        },
        child: const Icon(
          Icons.add,
          color: Colors.blue,
        ),
        backgroundColor: Colors.white,
      ),
      appBar: AppBar(
        backgroundColor: Colors.blueAccent,
        actions: const [
          Icon(
            Icons.search,
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Icon(
              Icons.list,
            ),
          ),
        ],
        title: Row(
          children: [
            const Icon(Icons.one_x_mobiledata_sharp),
            const Padding(
              padding: EdgeInsets.only(left: 10, right: 25),
              child: Text('to list'),
            ),
            DropdownButton(items: const []),
          ],
        ),
      ),
      body: Container(
        width: double.infinity,
        color: Colors.blue,
        child: Column(
          children:  [
            AddedLists(tasks),
          ],
        ),
      ),
    );
  }
}
