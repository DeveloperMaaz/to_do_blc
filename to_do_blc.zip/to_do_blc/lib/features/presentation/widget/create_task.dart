import 'dart:html';

import 'package:flutter/material.dart';
import 'package:to_do_blc/features/presentation/widget/screen_maine.dart';

class CreateTask extends StatefulWidget {
   var function;
   CreateTask(this.function);

  @override
  State<CreateTask> createState() => _CreateTaskState();
}

class _CreateTaskState extends State<CreateTask> {
  final _addTask=TextEditingController();

  final _addDiscription=TextEditingController();

   void press(){
     final titleControl=_addTask.text;
     final descControl=_addDiscription.text;

     widget.function(titleControl,descControl);
     Navigator.of(context).pop();
   }

   @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: const Text('New Task'),),
      body: Column(
        children:  [
         Padding(
           padding: const EdgeInsets.all(14.0),
           child: TextField(
             onSubmitted: (_)=>press(),
             controller: _addTask,
             decoration: const InputDecoration(
               labelText: 'what is to be done',
               hintText: 'Enter Task here'
             ),
           ),
         ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _addDiscription,
              onSubmitted: (_)=>press(),
              decoration: const InputDecoration(
                  labelText: 'what is you want write',
                  hintText: 'Enter Dicription here'
              ),
            ),
          ),
          InkWell(
            onTap: ()=>press(),
            child: const Text('Add Task'),
          )
        ],
      ),
    );
  }
}
