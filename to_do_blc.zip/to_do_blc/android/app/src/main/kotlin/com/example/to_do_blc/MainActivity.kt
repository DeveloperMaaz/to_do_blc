package com.example.to_do_blc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
